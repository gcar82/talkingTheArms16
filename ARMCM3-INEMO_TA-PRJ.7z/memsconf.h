/*
    ChibiOS - Copyright (C) 2016 Rocco Marco Guglielmi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    memsconf.h
 * @brief   MEMS configuration header.
 * @details MEMS configuration file, this file allows to enable or disable the
 *          various device drivers from your application. You may also use
 *          this file in order to override the device drivers default settings.
 *
 * @addtogroup MEMS_CONF
 * @{
 */

#ifndef _MEMSCONF_H_
#define _MEMSCONF_H_

#include "halconf.h"

/**
 * @name    Drivers enable switches
 */

/**
 * @brief   Enables the Accelerometer subsystem.
 */
#if !defined(MEMS_USE_ACCEL) || defined(__DOXYGEN__)
#define MEMS_USE_ACCEL               TRUE
#endif

/**
 * @brief   Enables the Compass subsystem.
 */
#if !defined(MEMS_USE_COMP) || defined(__DOXYGEN__)
#define MEMS_USE_COMP                TRUE
#endif

/**
 * @brief   Enables the Gyroscope subsystem.
 */
#if !defined(MEMS_USE_GYRO) || defined(__DOXYGEN__)
#define MEMS_USE_GYRO                TRUE
#endif

/**
 * @brief   Enables the peripherals MEMS subsystem.
 */
#if !defined(USE_P_MEMS) || defined(__DOXYGEN__)
#define USE_P_MEMS               TRUE
#endif

/*===========================================================================*/
/* P_MEMS driver related settings.                                           */
/*===========================================================================*/

/**
 * @brief   Enables MPU6050 drivers.
 * @note    If USE_P_MEMS is enabled, at least one driver must be enabled.
 */
#if !defined(EN_MPU6050D1) || defined(__DOXYGEN__)
#define EN_MPU6050D1               TRUE
#endif

#if !defined(EN_MPU6050D2) || defined(__DOXYGEN__)
#define EN_MPU6050D2               TRUE
#endif

#endif /* _MEMSCONF_H_ */

/** @} */
