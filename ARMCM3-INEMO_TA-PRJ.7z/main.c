/*
    ChibiOS/RT - Copyright (C) 2006-2016 Gennaro Carola

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
 */

#include "ch.h"
#include "hal.h"

#include "chprintf.h"
#include "usbcfg.h"

#include "gloves.h"

/*
 * Enable use of special ANSI escape sequences
 */
#define CHPRINTF_USE_ANSI_CODE         TRUE

/*
 * Serial over USB Driver structure.
 */
SerialUSBDriver SDU1;
static BaseSequentialStream *chp = (BaseSequentialStream*) &SDU1;

/*===========================================================================*/
/* Generic code.                                                             */
/*===========================================================================*/

dataframe_t glv_df[GLOVE_DATA_SIZE];

static WORKING_AREA(waThread1, 384);
static msg_t Thread1(void *arg) {

  (void)arg;
  chRegSetThreadName("gloves test");

  startDataGloves(&glv_dx);

  while(TRUE) {
    getDataGloves(&glv_dx, glv_df);
    chprintf(chp, "x_acc_dip_index, y_acc_dip_index, z_acc_dip_index, "
             "x_gyro_dip_index, y_gyro_dip_index, z_gyro_dip_index, "
             "x_acc_pip_index, y_acc_pip_index, z_acc_pip_index, "
             "x_gyro_pip_index, y_gyro_pip_index, z_gyro_pip_index, "
             "x_acc_wrist, y_acc_wrist, z_acc_wrist, "
             "x_comp_wrist, y_comp_wrist, z_comp_wrist,"
             "x_gyro_wrist, y_gyro_wrist, z_gyro_wrist;\r\n");
    chprintf(chp, "%f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f,  "
             "%f, %f, %f, %f, %f, %f, %f, %f, %f;\r\n",
             glv_df[INDEX_DIP_ACC].x, glv_df[INDEX_DIP_ACC].y,
             glv_df[INDEX_DIP_ACC].z,
             glv_df[INDEX_DIP_GYRO].x, glv_df[INDEX_DIP_GYRO].y,
             glv_df[INDEX_DIP_GYRO].z,
             glv_df[INDEX_PIP_ACC].x, glv_df[INDEX_PIP_ACC].y,
             glv_df[INDEX_PIP_ACC].z,
             glv_df[INDEX_PIP_GYRO].x, glv_df[INDEX_PIP_GYRO].y,
             glv_df[INDEX_PIP_GYRO].z,
             glv_df[WRIST_ACC].x, glv_df[WRIST_ACC].y, glv_df[WRIST_ACC].z,
             glv_df[WRIST_MAG].x, glv_df[WRIST_MAG].y, glv_df[WRIST_MAG].z,
             glv_df[WRIST_GYRO].x, glv_df[WRIST_GYRO].y, glv_df[WRIST_GYRO].z);
    chThdSleepMilliseconds(50);
#if CHPRINTF_USE_ANSI_CODE
    chprintf(chp, "\033[2J\033[1;1H");
#endif
  }
  return 0;
}

/*
 * Application entry point.
 */
int main(void) {

  /*
   * System initializations.
   * - HAL initialization, this also initializes the configured device drivers
   *   and performs the board-specific initializations.
   * - Kernel initialization, the main() function becomes a thread and the
   *   RTOS is active.
   */
  halInit();
  chSysInit();
  /*
   * Peripheral Abstract Layer initialization
   * - I2C1 I/O pins setup.
   */
  palSetPadMode(GPIOB, GPIOB_I2C1_SCL,
                PAL_MODE_STM32_ALTERNATE_OPENDRAIN);  /* SCL */
  palSetPadMode(GPIOB, GPIOB_I2C1_SDA,
                PAL_MODE_STM32_ALTERNATE_OPENDRAIN);  /* SDA */
  /*
   * Application library initialization.
   * - Gloves driver initialization.
   */
  initGloves();
  /*
   * Initializes a serial-over-USB CDC driver.
   */
  sduObjectInit(&SDU1);
  sduStart(&SDU1, &serusbcfg);
  /*
   * Activates the USB driver and then the USB bus pull-up on D+.
   * Note, a delay is inserted in order to not have to disconnect the cable
   * after a reset.
   */
  usbDisconnectBus(serusbcfg.usbp);
  chThdSleepMilliseconds(1500);
  usbStart(serusbcfg.usbp, &usbcfg);
  usbConnectBus(serusbcfg.usbp);

  /*
   * Creates polling data thread.
   */
  chThdCreateStatic(waThread1, sizeof(waThread1), (NORMALPRIO + 1),
                    Thread1, NULL);

  palSetPad(GPIOA, GPIOA_LED_BLUE);
  while (TRUE) {
    chThdSleepMilliseconds(500);
  }
  /*while (TRUE) {
    palSetPad(GPIOA, GPIOA_LED_BLUE);
    chThdSleepMilliseconds(250);
    palClearPad(GPIOA, GPIOA_LED_BLUE);
    chThdSleepMilliseconds(250);
  }*/
}
