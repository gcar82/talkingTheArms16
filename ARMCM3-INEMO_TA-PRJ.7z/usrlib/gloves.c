/*
    ChibiOS - Copyright (C) 2016 Gennaro Carola

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    gloves.c
 * @brief   Glove data device Complex Driver source.
 *
 * @addtogroup GLOVE_DEVICE
 * @{
 */

#include "hal.h"
#include "gloves.h"

/*===========================================================================*/
/* SPI Configurations                                                        */
/*===========================================================================*/

static const SPIConfig spi_cfg = {
  NULL,
  GPIOB,                                      /*   port of CS  */
  GPIOB_SPI2_CS,                              /*   pin of CS   */
  SPI_CR1_BR_0 | SPI_CR1_CPOL | SPI_CR1_CPHA, /*   CR1 register*/
};
/*===========================================================================*/
/* I2C Configurations                                                        */
/*===========================================================================*/

static const I2CConfig i2c_cfg = {
  OPMODE_I2C,
  400000,
  FAST_DUTY_CYCLE_2,
};
/*===========================================================================*/
/* ACCEL Configurations                                                       */
/*===========================================================================*/

static ACCELConfig accelcfg = {
  &I2CD2,
  LSM303DLHC_ACC_FS_2G,
  LSM303DLHC_ACC_ODR_400Hz,
  LSM303DLHC_ACC_AE_XYZ,
  LSM303DLHC_ACC_BDU_BLOCKED,
  LSM303DLHC_ACC_HR_Disabled,
  LSM303DLHC_ACC_End_LITTLE
};
/*===========================================================================*/
/* COMP Configurations                                                       */
/*===========================================================================*/

static COMPConfig compcfg = {
  &I2CD2,
  LSM303DLHC_COMP_FS_1_3_GA,
  LSM303DLHC_COMP_ODR_30_Hz,
  LSM303DLHC_COMP_WM_CONTINUOS
};
/*===========================================================================*/
/* GYRO Configurations                                                       */
/*===========================================================================*/

static GYROConfig gyrocfg = {
  &SPID2,
  L3GD20_FS_250DPS,
  L3GD20_ODR_760Hz_Fc_100,
  L3GD20_AE_XYZ,
  L3GD20_End_LITTLE,
  L3GD20_BDU_CONTINOUS
};
/*===========================================================================*/
/* MPU6050 MEMS Configurations                                               */
/*===========================================================================*/

static MPU6050Config mpu6050cfg = {
  &I2CD1,
  MPU6050_CLOCK_PLL_XGYRO,
  MPU6050_ACCEL_FS_2,
  MPU6050_GYRO_FS_250
};
/*============================================================================*/

static phalanx_t dip_index = {
  &MPU6050D1,
  &mpu6050cfg
};

static phalanx_t pip_index = {
  &MPU6050D2,
  &mpu6050cfg
};

static finger_t index = {
  &dip_index,
  &pip_index,
};

static mcuWrist_t wrist = {
  &ACCELD1,
  &GYROD1,
  &COMPD1,
  &accelcfg,
  &gyrocfg,
  &compcfg
};

extern dataframe_t glv_df[GLOVE_DATA_SIZE];
gloves_t glv_dx;

void initGloves() {

  memsInit();
  p_memsInit();
  glv_dx.side  = RIGHT;
  glv_dx.state = UNACTIVE;
}

gloveState_t stopDataGloves(gloves_t *glv_dx) {

  chDbgCheck(glv_dx != NULL, "stopDataGloves");

  chDbgAssert((glv_dx->state == UNACTIVE) || (glv_dx->state == READY),
              "stopDataGloves()", "invalid state");

  i2cStart(&PERIPH_I2C_DRV, &i2c_cfg);
  mpu6050Stop(glv_dx->index->dip->devp);
  mpu6050Stop(glv_dx->index->pip->devp);
  i2cStop(&PERIPH_I2C_DRV);

  i2cStart(&ON_BOARD_I2C_DRV, &i2c_cfg);
  accelStop(glv_dx->wrist->accelp);
  compStop(glv_dx->wrist->compp);
  i2cStop(&ON_BOARD_I2C_DRV);

  spiStart(&ON_BOARD_SPI_DRV, &spi_cfg);
  gyroStop(glv_dx->wrist->gyrop);
  spiStop(&ON_BOARD_SPI_DRV);

  glv_dx->state = UNACTIVE;

  return glv_dx->state;
}

gloveState_t startDataGloves(gloves_t *glv_dx) {

  chDbgCheck((glv_dx != NULL), "startDataGloves");

  chDbgAssert((glv_dx->state == UNACTIVE) || (glv_dx->state == READY),
              "startDataGloves()", "invalid state");

  glv_dx->index = &index;
  glv_dx->wrist = &wrist;
  i2cStart(&PERIPH_I2C_DRV, &i2c_cfg);
  mpu6050Start(glv_dx->index->dip->devp, glv_dx->index->dip->config);
  mpu6050Start(glv_dx->index->pip->devp, glv_dx->index->pip->config);
  i2cStop(&PERIPH_I2C_DRV);

  i2cStart(&ON_BOARD_I2C_DRV, &i2c_cfg);
  accelStart(glv_dx->wrist->accelp, glv_dx->wrist->accelcfg);
  compStart(glv_dx->wrist->compp, glv_dx->wrist->compcfg);
  i2cStop(&ON_BOARD_I2C_DRV);

  spiStart(&ON_BOARD_SPI_DRV, &spi_cfg);
  gyroStart(glv_dx->wrist->gyrop, glv_dx->wrist->gyrocfg);
  spiStop(&ON_BOARD_SPI_DRV);

  glv_dx->state = READY;

  return glv_dx->state;
}

gloveState_t getDataGloves(gloves_t *glv_dx, dataframe_t *glv_df) {

  chDbgCheck((glv_dx != NULL) && (glv_df != NULL) , "getDataGloves");
  /* add check length for glv_df */
  chDbgAssert((glv_dx->state == READY),
              "getDataGloves", "invalid state");

  i2cStart(&PERIPH_I2C_DRV, &i2c_cfg);
  mpu6050GetData(glv_dx->index->dip->devp, (glv_df + INDEX_DIP_ACC),
                 (glv_df + INDEX_DIP_GYRO));
  mpu6050GetData(glv_dx->index->pip->devp, (glv_df + INDEX_PIP_ACC),
                 (glv_df + INDEX_PIP_GYRO));
  i2cStop(&PERIPH_I2C_DRV);

  i2cStart(&ON_BOARD_I2C_DRV, &i2c_cfg);
  accelGetData(glv_dx->wrist->accelp, (glv_df + WRIST_ACC));
  compGetData(glv_dx->wrist->compp, (glv_df + WRIST_MAG));
  i2cStop(&ON_BOARD_I2C_DRV);

  spiStart(&ON_BOARD_SPI_DRV, &spi_cfg);
  gyroGetData(glv_dx->wrist->gyrop, (glv_df + WRIST_GYRO));
  spiStop(&ON_BOARD_SPI_DRV);

  glv_dx->state = READY;

  return glv_dx->state;
}
