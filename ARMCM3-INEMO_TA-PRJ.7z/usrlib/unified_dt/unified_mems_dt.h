#ifndef _UNIFIED_MEMS_DT_H_
#define _UNIFIED_MEMS_DT_H_

/**
 * @brief   MEMS data type
 * @details This axis data is to be considered as degrees per seconds for
 *          ACCEL & GYRO, for COMP is to be considered as Gauss
 */
typedef   float   rowdata_t;

/**
 * @brief   Number of axes.
 */
#define AXES                                0x03

/**
 * @brief   MEMS data frame
 */
typedef struct{
  rowdata_t x;
  rowdata_t y;
  rowdata_t z;
} dataframe_t;

/**
 * @brief   Driver state machine possible states.
 */
typedef enum {
  UNINIT = 0,                   /**< Not initialized.                   */
  STOP   = 1,                   /**< Stopped.                           */
  ACTIVE = 2,                   /**< Sampling data.                     */
} mems_state_t;

#endif /*_UNIFIED_MEMS_DT_H_*/
