/*
    ChibiOS - Copyright (C) 2016 Author

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    p_mems_mpu6050.h
 * @brief   MPU6050 MEMS complex driver header.
 *
 */

#ifndef _P_MEMS_MPU6050_H_
#define _P_MEMS_MPU6050_H_

#if USE_P_MEMS || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

#include "p_mems_mpu6050_lld.h"

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#ifdef __cplusplus
extern "C" {
#endif
  void mpu6050Init(void);
  void mpu6050ObjectInit(MPU6050Driver *);
  mems_state_t mpu6050Start(MPU6050Driver *, const MPU6050Config *);
  mems_state_t mpu6050Stop(MPU6050Driver *);
  mems_state_t mpu6050GetData(MPU6050Driver *, dataframe_t *, dataframe_t *);
  void mpu6050ChangeFullScale(MPU6050Driver *, MPU6050_ACCEL_FS_t,
                              MPU6050_GYRO_FS_t);
#ifdef __cplusplus
}
#endif
#endif  /* USE_P_MEMS*/
#endif /* _P_MEMS_MPU6050_H_ */

/** @} */
