/**
 * file    mpu6050.c
 *
 * brief   Handle mpu6050 mems chip on GY-521 board
 *
 * @addtogroup mpu6050
 * @{
 */
#include "hal.h"

#include "mpu6050.h"

#if USE_P_MEMS || defined(__DOXYGEN__)
/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/


/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Generic reads value using I2C.
 * @pre     The I2C interface must be initialized and the driver started.
 *
 * @param[in] i2cp      pointer to the I2C interface
 * @param[in] devAddr   Device address
 * @param[in] regAddr   register address
 * @param[in] bitStart  first bit to read
 * @param[in] bitLength bit offset
 * @param[in] length    number's bytes to read
 * @param[in] data      pointer to read buffer
 * @return              I2C status after reading.
 */
inline msg_t mpu6050_read(I2CDriver *i2cp, i2caddr_t devAddr, uint8_t regAddr,
                   uint8_t bitStart, uint8_t bitLength,
                   uint8_t length, uint8_t *data) {
  msg_t rdymsg;

#if defined(STM32F103_MCUCONF)
  if(length == 1)
    rdymsg = i2cMasterTransmitTimeout(i2cp, devAddr, &regAddr, 1, data,
                               (length + 1), TIME_INFINITE);
  else
    rdymsg = i2cMasterTransmitTimeout(i2cp, devAddr, &regAddr, 1, data, length,
                               TIME_INFINITE);

  if(rdymsg == RDY_TIMEOUT || rdymsg == RDY_RESET) {
    return FALSE;
  }
#else
  rdymsg = i2cMasterTransmitTimeout(i2cp, devAddr, &regAddr, 1, data, length,
                                    TIME_INFINITE);

  if(rdymsg == RDY_TIMEOUT || rdymsg == RDY_RESET)
    return FALSE;
#endif

  if (bitLength == 1) {
    *data &= (1 << bitStart);
    return rdymsg;
  }
  else if (bitLength > 1) {
    /** 01101001 read byte
     *  76543210 bit numbers
     *     bbb   args: bitStart=4, length=3
     *     010   masked
     *    -> 010 shifted
     */
    if (rdymsg != 0) {
      uint8_t mask = ((1 << bitLength) - 1) << (bitStart - bitLength + 1);
      *data &= mask;
      *data >>= (bitStart - bitLength + 1);
    }
    return rdymsg;
  }
  return rdymsg;
}

/**
 * @brief   Generic writes value using I2C.
 * @pre     The I2C interface must be initialized and the driver started.
 *
 * @param[in] i2cp      pointer to the I2C interface
 * @param[in] devAddr   Device address
 * @param[in] regAddr   register address
 * @param[in] bitStart  first bit to read
 * @param[in] bitLength bit offset
 * @param[in] length    number's bytes to read
 * @param[in] dp        pointer to write buffer
 * @param[in] data      data to write
 * @return              It returns a boolean according to the result of
 *                      the operation.(TRUE = success , FALSE = failed)
 */
inline bool_t mpu6050_write(I2CDriver *i2cp, i2caddr_t devAddr, uint8_t regAddr,
                     uint8_t bitStart, int8_t bitLength,
                     uint8_t length, uint8_t *dp, uint8_t data) {
  msg_t rdymsg;

  if (dp == NULL) {
    uint8_t b = 0;
#if defined(STM32F103_MCUCONF)
    if (length == 1)
      rdymsg = i2cMasterTransmitTimeout(i2cp, devAddr, &regAddr, 1, &b,
                                 (length + 1), TIME_INFINITE);
    else
      rdymsg = i2cMasterTransmitTimeout(i2cp, devAddr, &regAddr, 1, &b, length,
                                 TIME_INFINITE);

    if(rdymsg == RDY_TIMEOUT || rdymsg == RDY_RESET)
      return FALSE;
#else
    rdymsg = i2cMasterTransmitTimeout(i2cp, devAddr, &regAddr, 1, &b, length,
                                      TIME_INFINITE);

    if(rdymsg == RDY_TIMEOUT || rdymsg == RDY_RESET)
      return FALSE;
#endif

    if (bitLength == 1) {
      b = (data != 0) ? (b | (1 << bitStart)) : (b & ~(1 << bitStart));
#if defined(STM32F103_MCUCONF)
      if (length == 1)
        return i2cMasterTransmitTimeout(i2cp, devAddr, &regAddr, 1, &b,
                                 (length + 1), TIME_INFINITE);
      else
        return i2cMasterTransmitTimeout(i2cp, devAddr, &regAddr, 1, &b,
                                 (length + 1), TIME_INFINITE);
#endif
      return i2cMasterTransmitTimeout(i2cp, devAddr, &regAddr, 1, &b, length,
                                      TIME_INFINITE);
    }
    else if (bitLength > 1) {
      /**     010 value to write
       * 76543210 bit numbers
       *    bbb   args: bitStart=4, length=3
       * 00011100 mask byte
       * 10101111 original value (sample)
       * 10100011 original & ~mask
       * 10101011 masked | value
       */
      if (rdymsg != 0) {
        uint8_t mask = ((1 << bitLength) - 1) << (bitStart - bitLength + 1);
        data <<= (bitStart - bitLength + 1); /* shift data into correct position */
        data &= mask; /* zero all non-important bits in data */
        b &= ~(mask); /* zero all important bits in existing byte */
        b |= data; /* combine data with existing byte */
#if defined(STM32F103_MCUCONF)
        if (length == 1)
          return i2cMasterTransmitTimeout(i2cp, devAddr, &regAddr, 1, &b,
                                   (length + 1), TIME_INFINITE);
        else
          return i2cMasterTransmitTimeout(i2cp, devAddr, &regAddr, 1, &b,
                                   (length + 1), TIME_INFINITE);
#endif
        return i2cMasterTransmitTimeout(i2cp, devAddr, &regAddr, 1, &b, length,
                                        TIME_INFINITE);
      }
      else
        return FALSE;
    }
  }
  else {
    uint8_t i, txbuf[length +1], dummybuf[1];

    txbuf[0] = regAddr;
    for (i = 0; i < length; i++)
      txbuf[i + 1] = *(dp + i);

    rdymsg = i2cMasterTransmitTimeout(i2cp, devAddr, txbuf, length + 1,
                                      dummybuf, 0, TIME_INFINITE);
    if(rdymsg == RDY_TIMEOUT || rdymsg == RDY_RESET)
      return FALSE;
  }
  return FALSE;
}

#endif /* USE_P_MEMS */
/** @} */
