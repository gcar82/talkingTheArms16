/*
    ChibiOS - Copyright (C) 2016 Author

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    p_mems_mpu6050_lld.h
 * @brief   MPU6050 Complex Driver subsystem low level driver header.
 *
 * @addtogroup MPU6050
 * @{
 */

#ifndef _P_MEMS_MPU6050_LLD_H_
#define _P_MEMS_MPU6050_LLD_H_

#include "p_mems.h"

#if USE_P_MEMS || defined(__DOXYGEN__)

#include "mpu6050.h"
/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

#if !HAL_USE_I2C
  #error "MPU6050 Over I2C requires HAL_USE_I2C."
#endif

#if !EN_MPU6050D1 && !EN_MPU6050D2
  #error "Requires the enabling at least one between MPU6050D1, MPU6050D2."
#endif
/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

#include "unified_mems_dt.h"

/**
 * @brief   MPU6050 full scale type
 */
/* ??? */

/**
 * @brief   MPU6050 configuration structure.
 */
typedef struct {
  /**
   * @brief I2C driver associated to MPU6050.
   */
  I2CDriver           *i2cp;
  /**
   * @brief MPU6050 clock source setting.
   */
  MPU6050_CLOCK_t     clocksource;
  /**
   * @brief Accelerometer full scale value.
   */
  MPU6050_ACCEL_FS_t  AccelFullscale;
  /**
   * @brief Gyroscope full scale value.
   */
  MPU6050_GYRO_FS_t   GyroFullscale;

} MPU6050Config;

/**
 * @brief   Structure representing a MPU6050 driver.
 */
typedef struct {
  /**
   * @brief Device address.
   */
  i2caddr_t            devAddr;
  /**
   * @brief Driver state.
   */
  mems_state_t         state;
  /**
   * @brief Current configuration data.
   */
  const MPU6050Config  *config;
  /**
   * @brief Current gyroscope sensitivity.
   */
  rowdata_t            gyroSens;
  /**
   * @brief Current accelerometer sensitivity.
   */
  rowdata_t            accelSens;
} MPU6050Driver;
/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/
#if EN_MPU6050D1
  extern MPU6050Driver MPU6050D1;
#endif

#if EN_MPU6050D2
  extern MPU6050Driver MPU6050D2;
#endif


#ifdef __cplusplus
extern "C" {
#endif
  void mpu6050_lld_init(void);
  void mpu6050_lld_start(MPU6050Driver *);
  void mpu6050_lld_stop(MPU6050Driver *);
  void mpu6050_lld_getdata(MPU6050Driver *, dataframe_t *, dataframe_t *);
  void mpu6050_lld_change_fullscale(MPU6050Driver *, MPU6050_ACCEL_FS_t,
                                    MPU6050_GYRO_FS_t);
#ifdef __cplusplus
}
#endif
#endif /* USE_P_MEMS */
#endif /* _P_MEMS_MPU6050_LLD_H_ */

/** @} */
