/*
    ChibiOS - Copyright (C) 2016 Author

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
 */

/**
 * @file    p_mems_mpu6050_lld.c
 * @brief   MPU6050 MEMS Complex Driver subsystem low level driver source.
 *
 * @addtogroup MPU6050
 * @{
 */

#include "ch.h"
#include "hal.h"

#include "p_mems.h"

#if USE_P_MEMS || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
 * @brief   MPU6050 drivers identifier.
 */

#if EN_MPU6050D1
MPU6050Driver MPU6050D1;
#endif

#if EN_MPU6050D2
MPU6050Driver MPU6050D2;
#endif


/*===========================================================================*/
/* Driver local types.                                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Low level MPU6050 driver initialization.
 *
 * @notapi
 */
void mpu6050_lld_init(void) {

#if EN_MPU6050D1
  MPU6050D1.devAddr = MPU6050_ADDRESS_AD0_LOW;
  mpu6050ObjectInit(&MPU6050D1);
#endif

#if EN_MPU6050D2
  MPU6050D2.devAddr = MPU6050_ADDRESS_AD0_HIGH;
  mpu6050ObjectInit(&MPU6050D2);
#endif
}

/**
 * @brief   Configures and activates the MPU6050 MEMS Complex Driver peripheral.
 * @note    I2C must be started
 *
 * @param[in] drvp      pointer to the @p MPU6050Driver object
 *
 * @notapi
 */
void mpu6050_lld_start(MPU6050Driver *drvp) {

  chDbgAssert((drvp->config->i2cp->state == I2C_READY),
              "mpu6050_lld_start()","channel not ready");
#if I2C_USE_MUTUAL_EXCLUSION
  i2cAcquireBus(drvp->config->i2cp);
#endif
  chThdSleepMilliseconds(MPU6050_START_UP_TIME_MAX);
  mpu6050_write(drvp->config->i2cp, drvp->devAddr, MPU6050_RA_PWR_MGMT_1,
                MPU6050_PWR1_CLKSEL_BIT, MPU6050_PWR1_CLKSEL_LENGTH,
                1, NULL, drvp->config->clocksource);
  mpu6050_write(drvp->config->i2cp, drvp->devAddr, MPU6050_RA_GYRO_CONFIG,
                MPU6050_GCONFIG_FS_SEL_BIT, MPU6050_GCONFIG_FS_SEL_LENGTH,
                1, NULL, drvp->config->GyroFullscale);
  mpu6050_write(drvp->config->i2cp, drvp->devAddr, MPU6050_RA_ACCEL_CONFIG,
                MPU6050_ACONFIG_AFS_SEL_BIT, MPU6050_ACONFIG_AFS_SEL_LENGTH,
                1, NULL, drvp->config->AccelFullscale);
  mpu6050_write(drvp->config->i2cp, drvp->devAddr, MPU6050_RA_PWR_MGMT_1,
                MPU6050_PWR1_SLEEP_BIT, 1, 1, NULL, FALSE);
#if I2C_USE_MUTUAL_EXCLUSION
  i2cReleaseBus(drvp->config->i2cp);
#endif

  /* Storing sensitivity information according to full scale value */
  switch (drvp->config->GyroFullscale) {
  case MPU6050_GYRO_FS_250:
    drvp->gyroSens = MPU6050_GYRO_LSB_SEN_FS_250;
    break;
  case MPU6050_GYRO_FS_500:
    drvp->gyroSens = MPU6050_GYRO_LSB_SEN_FS_500;
    break;
  case MPU6050_GYRO_FS_1000:
    drvp->gyroSens = MPU6050_GYRO_LSB_SEN_FS_1000;
    break;
  case MPU6050_GYRO_FS_2000:
    drvp->gyroSens = MPU6050_GYRO_LSB_SEN_FS_2000;
    break;
  default:
    chDbgAssert(FALSE, "mpu6050_lld_start()", "gyroscope full scale issue");
  }

  switch (drvp->config->AccelFullscale) {
  case MPU6050_ACCEL_FS_2:
    drvp->accelSens = MPU6050_ACCEL_LSB_SEN_FS_2;
    break;
  case MPU6050_ACCEL_FS_4:
    drvp->accelSens = MPU6050_ACCEL_LSB_SEN_FS_4;
    break;
  case MPU6050_ACCEL_FS_8:
    drvp->accelSens = MPU6050_ACCEL_LSB_SEN_FS_8;
    break;
  case MPU6050_ACCEL_FS_16:
    drvp->accelSens = MPU6050_ACCEL_LSB_SEN_FS_16;
    break;
  default:
    chDbgAssert(FALSE, "mpu6050_lld_start()",
                "accelerometer full scale issue");
  }
  /* This is the transient recovery time*/
  chThdSleepMilliseconds(10);
}

/**
 * @brief   Deactivates the MPU6050 MEMS Complex Driver peripheral.
 * @note    I2C must be started
 *
 * @param[in] drvp      pointer to the @p MPU6050Driver object
 *
 * @notapi
 */
void mpu6050_lld_stop(MPU6050Driver *drvp) {

  chDbgAssert((drvp->config->i2cp->state == I2C_READY),
              "mpu6050_lld_stop", "channel not ready");
  if (drvp->state == ACTIVE) {
#if I2C_USE_MUTUAL_EXCLUSION
    i2cAcquireBus(drvp->config->i2cp);
#endif
    mpu6050_write(drvp->config->i2cp, drvp->devAddr, MPU6050_RA_PWR_MGMT_1,
                  MPU6050_PWR1_SLEEP_BIT, 1, 1, NULL, TRUE);
    /* This is the transient recovery time */
    chThdSleepMilliseconds(100);
#if I2C_USE_MUTUAL_EXCLUSION
    i2cAcquireBus(drvp->config->i2cp);
#endif
  }

}

/**
 * @brief   Get data from the MPU6050 MEMS Complex Driver peripheral.
 * @note    I2C must be started
 *
 * @param[in] drvp            pointer to the @p MPU6050Driver object
 * @param[in] acceldata       pointer to the @p dataframe_t object
 * @param[in] gyrodata        pointer to the @p dataframe_t object

 * @notapi
 */
void mpu6050_lld_getdata(MPU6050Driver *drvp, dataframe_t *acceldata,
                         dataframe_t *gyrodata) {

  chDbgAssert( (drvp->config->i2cp->state == I2C_READY),
               "mpu6050_lld_getdata()", "channel not ready");
  uint8_t rxbuf[2];
  int16_t value;
  rowdata_t* acceldatap = (rowdata_t*)acceldata;
  rowdata_t* gyrodatap  = (rowdata_t*)gyrodata;

#if I2C_USE_MUTUAL_EXCLUSION
  i2cAcquireBus(drvp->config->i2cp);
#endif
  mpu6050_write(drvp->config->i2cp, drvp->devAddr, MPU6050_RA_PWR_MGMT_1,
                MPU6050_PWR1_SLEEP_BIT, 1, 1, NULL, FALSE);
  /*thanks to Jack Elston for pointing this one out!*/
  chThdSleepMilliseconds(50);
  mpu6050_read(drvp->config->i2cp, drvp->devAddr,
               MPU6050_RA_ACCEL_XOUT_H, 0, 0, 2, rxbuf);

  value = (((int16_t)rxbuf[0]) << 8) | rxbuf[1];
  *acceldatap = value * drvp->accelSens;
  acceldatap++;
  mpu6050_read(drvp->config->i2cp, drvp->devAddr,
               MPU6050_RA_ACCEL_YOUT_H, 0, 0, 2, rxbuf);
  value = (((int16_t)rxbuf[0]) << 8) | rxbuf[1];
  *acceldatap = value * drvp->accelSens;
  acceldatap++;
  mpu6050_read(drvp->config->i2cp, drvp->devAddr,
               MPU6050_RA_ACCEL_ZOUT_H, 0, 0, 2, rxbuf);
  value = (((int16_t)rxbuf[0]) << 8) | rxbuf[1];
  *acceldatap = value * drvp->accelSens;

  mpu6050_read(drvp->config->i2cp, drvp->devAddr,
               MPU6050_RA_GYRO_XOUT_H, 0, 0, 2, rxbuf);
  value = (((int16_t)rxbuf[0]) << 8) | rxbuf[1];
  *gyrodatap = value / drvp->gyroSens;
  gyrodatap++;
  mpu6050_read(drvp->config->i2cp, drvp->devAddr,
               MPU6050_RA_GYRO_YOUT_H, 0, 0, 2, rxbuf);
  value = (((int16_t)rxbuf[0]) << 8) | rxbuf[1];
  *gyrodatap = value / drvp->gyroSens;
  gyrodatap++;
  mpu6050_read(drvp->config->i2cp, drvp->devAddr,
                 MPU6050_RA_GYRO_ZOUT_H, 0, 0, 2, rxbuf);
  value = (((int16_t)rxbuf[0]) << 8) | rxbuf[1];
  *gyrodatap = value / drvp->gyroSens;
#if I2C_USE_MUTUAL_EXCLUSION
  i2cReleaseBus(drvp->config->i2cp);
#endif
}

/**
 * @brief   Changes the full scale value of the MPU6050 MEMS
 *          Complex Driver peripheral.
 * @note    I2C must be started
 *
 * @param[in] drvp      pointer to the @p MPU6050Driver object
 * @param[in] afs       the chosen accelerometer full scale value
 * @param[in] gfs       the chosen gyroscope full scale value
 *
 * @notapi
 */
void mpu6050_lld_change_fullscale(MPU6050Driver *drvp, MPU6050_ACCEL_FS_t afs,
                                  MPU6050_GYRO_FS_t gfs) {

  chDbgAssert((drvp->config->i2cp->state == I2C_READY),
              "mpu6050_lld_change_fullscale", "channel not ready");
#if I2C_USE_MUTUAL_EXCLUSION
  i2cAcquireBus(drvp->config->i2cp);
#endif
  mpu6050_write(drvp->config->i2cp, drvp->devAddr, MPU6050_RA_GYRO_CONFIG,
                  MPU6050_GCONFIG_FS_SEL_BIT, MPU6050_GCONFIG_FS_SEL_LENGTH,
                  1, NULL, gfs);
  mpu6050_write(drvp->config->i2cp, drvp->devAddr, MPU6050_RA_ACCEL_CONFIG,
                  MPU6050_ACONFIG_AFS_SEL_BIT, MPU6050_ACONFIG_AFS_SEL_LENGTH,
                  1, NULL, afs);
#if I2C_USE_MUTUAL_EXCLUSION
  i2cReleaseBus(drvp->config->i2cp);
#endif

  /* Storing sensitivity information according to full scale value */
  switch (drvp->config->GyroFullscale) {
  case MPU6050_GYRO_FS_250:
    drvp->gyroSens = MPU6050_GYRO_LSB_SEN_FS_250;
    break;
  case MPU6050_GYRO_FS_500:
    drvp->gyroSens = MPU6050_GYRO_LSB_SEN_FS_500;
    break;
  case MPU6050_GYRO_FS_1000:
    drvp->gyroSens = MPU6050_GYRO_LSB_SEN_FS_1000;
    break;
  case MPU6050_GYRO_FS_2000:
    drvp->gyroSens = MPU6050_GYRO_LSB_SEN_FS_2000;
    break;
  default:
    chDbgAssert(FALSE, "mpu6050_lld_start()", "gyroscope full scale issue");
  }

  switch (drvp->config->AccelFullscale) {
  case MPU6050_ACCEL_FS_2:
    drvp->accelSens = MPU6050_ACCEL_LSB_SEN_FS_2;
    break;
  case MPU6050_ACCEL_FS_4:
    drvp->accelSens = MPU6050_ACCEL_LSB_SEN_FS_4;
    break;
  case MPU6050_ACCEL_FS_8:
    drvp->accelSens = MPU6050_ACCEL_LSB_SEN_FS_8;
    break;
  case MPU6050_ACCEL_FS_16:
    drvp->accelSens = MPU6050_ACCEL_LSB_SEN_FS_16;
    break;
  default:
    chDbgAssert(FALSE, "mpu6050_lld_start()", "accelerometer full scale issue");
  }
}
#endif /* USE_P_MEMS */

/** @} */
