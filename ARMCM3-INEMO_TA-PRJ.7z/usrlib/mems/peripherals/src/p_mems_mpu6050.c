/*
    ChibiOS - Copyright (C) 2016 Author

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    p_mems_mpu6050.c
 * @brief   MPU6050 MEMS complex driver code.
 *
 * @addtogroup MPU6050
 * @{
 */

#include "ch.h"
#include "hal.h"

#include "p_mems.h"

#if USE_P_MEMS || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local types.                                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   MPU6050 MEMS Complex Driver initialization.
 * @note    This function is implicitly invoked by @p p_memsInit(), there is
 *          no need to explicitly initialize the driver.
 *
 * @init
 */
void mpu6050Init(void) {

  return mpu6050_lld_init();
}

/**
 * @brief   Initializes an instance.
 *
 * @param[out] drvp         pointer to the @p MPU6050Driver object
 *
 * @init
 */
void mpu6050ObjectInit(MPU6050Driver *drvp){

  drvp->state  = STOP;
  drvp->config = NULL;

}

/**
 * @brief   Configures and activates the MPU6050 MEMS Complex Driver  peripheral.
 *
 * @param[in] drvp      pointer to the @p MPU6050Driver object
 * @param[in] config    pointer to the @p MPU6050Config object
 * @return              update MPU6050Driver status
 *
 * @api
 */
mems_state_t mpu6050Start(MPU6050Driver *drvp, const MPU6050Config *config) {

  chDbgCheck((drvp != NULL) && (config != NULL), "mpu6050Start");

  chDbgAssert((drvp->state == STOP) || (drvp->state == ACTIVE),
              "mpu6050Start()", "invalid state");
  drvp->config = config;
  mpu6050_lld_start(drvp);
  drvp->state = ACTIVE;

  return drvp->state;
}

/**
 * @brief   Deactivates the MPU6050 MEMS Complex Driver  peripheral.
 *
 * @param[in] drvp      pointer to the @p MPU6050Driver object
 * @return              update MPU6050Driver status
 * @api
 */
mems_state_t mpu6050Stop(MPU6050Driver *drvp) {

  chDbgCheck(drvp != NULL, "mpu6050Stop");

  chDbgAssert((drvp->state == STOP) || (drvp->state == ACTIVE),
              "mpu6050Stop()", "invalid state");
  mpu6050_lld_stop(drvp);
  drvp->state = STOP;

  return drvp->state;
}

/**
 * @brief   Get data from the MPU6050 MEMS Complex Driver peripheral.
 *
 * @param[in] drvp       pointer to the @p MPU6050Driver object
 * @param[in] acceldata  pointer to the @p dataframe_t object
 * @param[in] gyrodata   pointer to the @p dataframe_t object
 * @return              update MPU6050Driver status
 * @api
 */
mems_state_t mpu6050GetData(MPU6050Driver *drvp, dataframe_t *acceldata,
                      dataframe_t *gyrodata) {

  chDbgCheck((drvp != NULL) && (acceldata != NULL) && (gyrodata != NULL),
             "mpu6050GetData");

  chDbgAssert((drvp->state == ACTIVE),
              "mpu6050GetData()", "invalid state");
  mpu6050_lld_getdata(drvp, acceldata, gyrodata);
  drvp->state = ACTIVE;

  return drvp->state;
}

/**
 * @brief   Changes the full scale value of the MPU6050 MEMS
 *           Complex Driver peripheral.
 *
 * @param[in] drvp      pointer to the @p ACCELDriver object
 * @param[in] afs       the chosen accelerometer  full scale value
 * @param[in] gfs       the chosen gyroscope full scale value
 *
 * @api
 */
void mpu6050ChangeFullScale(MPU6050Driver *drvp, MPU6050_ACCEL_FS_t afs,
                              MPU6050_GYRO_FS_t gfs) {

  chDbgCheck((drvp != NULL), "mpu6050ChangeFullScale");

  chDbgAssert((drvp->state == ACTIVE) || (drvp->state == STOP),
              "mpu6050ChangeFullScale", "invalid state");
  mpu6050_lld_change_fullscale(drvp, afs, gfs);
}
#endif /* USE_P_MEMS */

/** @} */
