/*
    ChibiOS - Copyright (C) 2016 Rocco Marco Guglielmi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    memsgyro.c
 * @brief   GYRO complex Complex Driver code.
 *
 * @addtogroup GYRO
 * @{
 */

#include "ch.h"
#include "hal.h"

#include "mems.h"

#if MEMS_USE_GYRO || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local types.                                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   GYRO Complex Driver initialization.
 * @note    This function is implicitly invoked by @p playInit(), there is
 *          no need to explicitly initialize the Complex Driver.
 *
 * @init
 */
void gyroInit(void) {

  gyro_lld_init();
}

/**
 * @brief   Initializes an instance.
 *
 * @param[out] gyrop     pointer to the @p GYRODriver object
 *
 * @init
 */
void gyroObjectInit(GYRODriver *gyrop) {

  gyrop->state  = STOP;
  gyrop->config = NULL;
}

/**
 * @brief   Configures and activates GYRO Complex Driver peripheral.
 *
 * @param[in] gyrop      pointer to the @p GYRODriver object
 * @param[in] config     pointer to the @p GYROConfig object
 *
 * @api
 */
void gyroStart(GYRODriver *gyrop, const GYROConfig *config) {

  chDbgCheck((gyrop != NULL) && (config != NULL), "gyroStart");
  chDbgAssert((gyrop->state == STOP) || (gyrop->state == ACTIVE),
              "gyroStart()", "invalid state");
  gyrop->config = config;
  gyro_lld_start(gyrop);
  gyrop->state = ACTIVE;
}

/**
 * @brief   Deactivates the GYRO Complex Driver peripheral.
 *
 * @param[in] gyrop      pointer to the @p GYRODriver object
 *
 * @api
 */
void gyroStop(GYRODriver *gyrop) {

  chDbgCheck(gyrop != NULL, "gyroStop");

  chDbgAssert((gyrop->state == STOP) || (gyrop->state == ACTIVE),
              "gyroStop()", "invalid state");
  gyro_lld_stop(gyrop);
  gyrop->state = STOP;
}

/**
 * @brief   Get offset from the GYRO Complex Driver peripheral.
 * @note    The offset is stored into driver structure.
 *
 * @detail  Offset should be recomputed if configurations change.
 *
 * @detail  The offset of the GYRO is equal to the data acquired while
 *          holding the GYRO. The noise filtering requires a median filter
 * @param[in] gyrop      pointer to the @p GYRODriver object
 *
 * @api
 */
void gyroGetOffset(GYRODriver *gyrop) {

  dataframe_t data;
  int32_t i, tmp[GYRO_AXES];

  chDbgCheck(gyrop != NULL, "gyroGetOffset");
  chDbgAssert((gyrop->state == ACTIVE),
              "gyroGetOffset()", "invalid state");
  for(i = 0; i < GYRO_AXES; i++) {
    tmp[i] = 0;
  }

  for(i = 0; i < GYRO_OFF_ACQ_TIMES; i++) {
    gyro_lld_getdata(gyrop, &data);
    tmp[0] += data.x;
    tmp[1] += data.y;
    tmp[2] += data.z;
    chThdSleepMicroseconds(GYRO_OFF_SET_TIME_uS);
  }
  gyrop->offset.x = (tmp[0] / GYRO_OFF_ACQ_TIMES);
  gyrop->offset.y = (tmp[1] / GYRO_OFF_ACQ_TIMES);
  gyrop->offset.z = (tmp[2] / GYRO_OFF_ACQ_TIMES);
}

/**
 * @brief   Reset offset of GYRO Complex Driver peripheral.
 *
 * @param[in] gyrop      pointer to the @p GYRODriver object
 *
 * @api
 */
void gyroResetOffset(GYRODriver *gyrop) {

  chDbgCheck(gyrop != NULL, "gyroResetOffset");
  chDbgAssert((gyrop->state == ACTIVE),
              "gyroResetOffset()", "invalid state");
  gyrop->offset.x = 0;
  gyrop->offset.y = 0;
  gyrop->offset.z = 0;
}

/**
 * @brief   Get data from the GYRO Complex Driver peripheral.
 *
 * @param[in] gyrop      pointer to the @p GYRODriver object
 * @param[in] datap      pointer to the @p GYRODataframe_t object
 *
 * @api
 */
void gyroGetData(GYRODriver *gyrop, dataframe_t *datap) {

  chDbgCheck((gyrop != NULL) && (datap != NULL), "gyroGetData");

  chDbgAssert((gyrop->state == ACTIVE),
              "gyroGetData()", "invalid state");
  gyro_lld_getdata(gyrop, datap);
}

/**
 * @brief   Changes the full scale value of the GYRO Complex Driver peripheral.
 *
 * @param[in] gyrop      pointer to the @p GYRODriver object
 * @param[in] fs         the chosen full scale value
 *
 * @api
 */
void gyroChangeFullScale(GYRODriver *gyrop, GYROFullScale_t fs) {

  chDbgCheck(gyrop != NULL, "gyroChangeFullScale");

  chDbgAssert((gyrop->state == ACTIVE) || (gyrop->state == STOP),
              "gyroChangeFullScale()", "invalid state");
  gyro_lld_change_fullscale(gyrop, fs);
}
#endif /* MEMS_USE_GYRO */

