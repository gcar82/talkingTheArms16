/*
    ChibiOS - Copyright (C) 2016 Rocco Marco Guglielmi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    memscomp.c
 * @brief   COMP complex driver code.
 *
 * @addtogroup COMP
 * @{
 */

#include "ch.h"
#include "hal.h"

#include "mems.h"

#if MEMS_USE_COMP || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local types.                                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   COMP Complex Driver initialization.
 * @note    This function is implicitly invoked by @p playInit(), there is
 *          no need to explicitly initialize the driver.
 *
 * @init
 */
void compInit(void) {

  comp_lld_init();
}

/**
 * @brief   Initializes an instance.
 *
 * @param[out] compp         pointer to the @p COMPDriver object
 *
 * @init
 */
void compObjectInit(COMPDriver *compp){

  compp->state  = STOP;
  compp->config = NULL;
}

/**
 * @brief   Configures and activates the COMP Complex Driver peripheral.
 *
 * @param[in] compp   pointer to the @p COMPDriver object
 * @param[in] config    pointer to the @p COMPConfig object
 *
 * @api
 */
void compStart(COMPDriver *compp, const COMPConfig *config) {

  chDbgCheck((compp != NULL) && (config != NULL), "compStart");

  chDbgAssert((compp->state == STOP) || (compp->state == ACTIVE),
              "compStart()", "invalid state");
  compp->config = config;
  comp_lld_start(compp);
  compp->state = ACTIVE;
}

/**
 * @brief   Deactivates the CCOMP Complex Driver peripheral.
 *
 * @param[in] compp      pointer to the @p COMPDriver object
 *
 * @api
 */
void compStop(COMPDriver *compp) {

  chDbgCheck(compp != NULL, "compStop");

  chDbgAssert((compp->state == STOP) || (compp->state == ACTIVE),
              "compStop()", "invalid state");
  comp_lld_stop(compp);
  compp->state = STOP;
}

/**
 * @brief   Get data from the COMP Complex Driver peripheral.
 *
 * @param[in] compp      pointer to the @p COMPDriver object
 * @param[in] datap        pointer to the @p COMPDataframe_t object
 *
 * @api
 */
void compGetData(COMPDriver *compp, dataframe_t *datap){

  chDbgCheck((compp != NULL) && (datap != NULL), "compGetData");

  chDbgAssert((compp->state == ACTIVE),
              "compGetData()", "invalid state");
  comp_lld_getdata(compp, datap);
  compp->state = ACTIVE;
}

/**
 * @brief   Changes the full scale value of the COMP Complex Driver peripheral.
 *
 * @param[in] compp      pointer to the @p COMPDriver object
 * @param[in] fs         the chosen full scale value
 *
 * @api
 */
void compChangeFullScale(COMPDriver *compp, COMPFullScale_t fs) {

  chDbgCheck((compp != NULL), "compChangeFullScale");

  chDbgAssert((compp->state == ACTIVE) || (compp->state == STOP),
              "compChangeFullScale()", "invalid state");
  comp_lld_change_fullscale(compp, fs);
}
#endif /* MEMS_USE_COMP */

/** @} */
