/*
    ChibiOS - Copyright (C) 2016 Rocco Marco Guglielmi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    memsaccel.c
 * @brief   ACCEL complex driver code.
 *
 * @addtogroup ACCEL
 * @{
 */

#include "ch.h"
#include "hal.h"

#include "mems.h"

#if MEMS_USE_ACCEL || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local types.                                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   ACCEL Complex Driver initialization.
 * @note    This function is implicitly invoked by @p playInit(), there is
 *          no need to explicitly initialize the driver.
 *
 * @init
 */
void accelInit(void) {

  accel_lld_init();
}

/**
 * @brief   Initializes an instance.
 *
 * @param[out] accelp         pointer to the @p ACCELDriver object
 *
 * @init
 */
void accelObjectInit(ACCELDriver *accelp){

  accelp->state  = STOP;
  accelp->config = NULL;
}

/**
 * @brief   Configures and activates the ACCEL Complex Driver  peripheral.
 *
 * @param[in] accel   pointer to the @p ACCELDriver object
 * @param[in] config    pointer to the @p ACCELConfig object
 *
 * @api
 */
void accelStart(ACCELDriver *accelp, const ACCELConfig *config) {

  chDbgCheck((accelp != NULL) && (config != NULL), "accelStart");

  chDbgAssert((accelp->state == STOP) || (accelp->state == ACTIVE),
              "accelStart()", "invalid state");
  accelp->config = config;
  accel_lld_start(accelp);
  accelp->state = ACTIVE;
}

/**
 * @brief   Deactivates the ACCEL Complex Driver  peripheral.
 *
 * @param[in] accelp      pointer to the @p ACCELDriver object
 *
 * @api
 */
void accelStop(ACCELDriver *accelp) {

  chDbgCheck(accelp != NULL, "accelStop");

  chDbgAssert((accelp->state == STOP) || (accelp->state == ACTIVE),
              "accelStop()", "invalid state");
  accel_lld_stop(accelp);
  accelp->state = STOP;
}

/**
 * @brief   Get data from the ACCEL Complex Driver peripheral.
 *
 * @param[in] accelp      pointer to the @p ACCELDriver object
 * @param[in] datap        pointer to the @p ACCELDataframe_t object
 *
 * @api
 */
void accelGetData(ACCELDriver *accelp, dataframe_t *datap){

  chDbgCheck((accelp != NULL) && (datap != NULL), "accelGetData");

  chDbgAssert((accelp->state == ACTIVE),
              "accelGetData()", "invalid state");
  accel_lld_getdata(accelp, datap);
  accelp->state = ACTIVE;
}

/**
 * @brief   Changes the full scale value of the ACCEL Complex Driver peripheral.
 *
 * @param[in] accelp      pointer to the @p ACCELDriver object
 * @param[in] fs         the chosen full scale value
 *
 * @api
 */
void accelChangeFullScale(ACCELDriver *accelp, ACCELFullScale_t fs) {

  chDbgCheck((accelp != NULL), "accelChangeFullScale");

  chDbgAssert((accelp->state == ACTIVE) || (accelp->state == STOP),
              "accelChangeFullScale()", "invalid state");
  accel_lld_change_fullscale(accelp, fs);
}
#endif /* MEMS_USE_ACCEL */

/** @} */
