/*
    ChibiOS - Copyright (C) 2016 Rocco Marco Guglielmi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    l3gd20.c
 * @brief   L3GD20 MEMS interface module code.
 *
 * @addtogroup l3gd20
 * @{
 */

#include "ch.h"
#include "hal.h"

#include "l3gd20.h"

#if MEMS_USE_GYRO || defined(__DOXYGEN__)
/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Reads a generic register value using SPI.
 * @pre     The SPI interface must be initialized and the driver started.
 *
 * @param[in] spip      pointer to the SPI interface
 * @param[in] reg       register number
 * @return              register value.
 */
uint8_t l3gd20ReadRegisterSPI(SPIDriver *spip, uint8_t reg) {
  uint8_t txbuf[2] = {L3GD20_RW | reg, 0xFF};
  uint8_t rxbuf[2] = {0x00, 0x00};
  spiSelect(spip);
  spiExchange(spip, 2, txbuf, rxbuf);
  spiUnselect(spip);
  return rxbuf[1];
}

/**
 * @brief   Writes a value into a generic register using SPI.
 * @pre     The SPI interface must be initialized and the driver started.
 *
 * @param[in] spip      pointer to the SPI interface
 * @param[in] reg       register number
 * @param[in] value     register value.
 */
void l3gd20WriteRegisterSPI(SPIDriver *spip, uint8_t reg, uint8_t value) {

  switch (reg) {

    default:
      /* Reserved register must not be written, according to the datasheet
       * this could permanently damage the device.
       */
      chDbgAssert(FALSE, "l3gd20WriteRegisterSPI()", "reserved register");
    case L3GD20_AD_WHO_AM_I:
    case L3GD20_AD_OUT_TEMP :
    case L3GD20_AD_STATUS_REG:
    case L3GD20_AD_OUT_X_L:
    case L3GD20_AD_OUT_X_H:
    case L3GD20_AD_OUT_Y_L:
    case L3GD20_AD_OUT_Y_H:
    case L3GD20_AD_OUT_Z_L:
    case L3GD20_AD_OUT_Z_H:
    case L3GD20_AD_FIFO_SRC_REG:
    case L3GD20_AD_INT1_SRC:
    /* Read only registers cannot be written, the command is ignored.*/
      return;
    case L3GD20_AD_CTRL_REG1:
    case L3GD20_AD_CTRL_REG2:
    case L3GD20_AD_CTRL_REG3:
    case L3GD20_AD_CTRL_REG4:
    case L3GD20_AD_CTRL_REG5:
    case L3GD20_AD_REFERENCE:
    case L3GD20_AD_FIFO_CTRL_REG:
    case L3GD20_AD_INT1_CFG:
    case L3GD20_AD_INT1_TSH_XH:
    case L3GD20_AD_INT1_TSH_XL:
    case L3GD20_AD_INT1_TSH_YH:
    case L3GD20_AD_INT1_TSH_YL:
    case L3GD20_AD_INT1_TSH_ZH:
    case L3GD20_AD_INT1_TSH_ZL:
    case L3GD20_AD_INT1_DURATION:
      spiSelect(spip);
      uint8_t txbuf[2] = {reg, value};
      spiSend(spip, 2, txbuf);
      spiUnselect(spip);
  }
}
#endif /* MEMS_USE_GYRO */
/** @} */
