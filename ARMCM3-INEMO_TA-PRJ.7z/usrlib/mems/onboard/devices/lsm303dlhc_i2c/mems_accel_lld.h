/*
    ChibiOS - Copyright (C) 2016 Rocco Marco Guglielmi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    accel_lld.h
 * @brief   ACCEL Complex Driver subsystem low level driver header.
 *
 * @addtogroup ACCEL
 * @{
 */

#ifndef _MEMS_ACCEL_LLD_H_
#define _MEMS_ACCEL_LLD_H_

#include "mems.h"

#if MEMS_USE_ACCEL || defined(__DOXYGEN__)

#include "lsm303dlhc.h"
/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/**
 * @brief   Number of axes.
 */
#define ACCEL_AXES                               0x03
/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

#if !HAL_USE_I2C
#error "LSM303DLHC Over I2C requires HAL_USE_I2C."
#endif
/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

#include "unified_mems_dt.h"

/**
 * @brief   ACCEL full scale type
 */
typedef  LSM303DLHC_ACC_FS_t ACCELFullScale_t;

/**
 * @brief   ACCEL configuration structure.
 */
typedef struct {

  /**
   * @brief I2C driver associated to this GYROSCOPE.
   */
  I2CDriver  *i2cp;
  /**
   * @brief Accelerometer fullscale value.
   */
  LSM303DLHC_ACC_FS_t    fullscale;
  /**
   * @brief Accelerometer output data rate selection.
   */
  LSM303DLHC_ACC_ODR_t   outputdatarate;
  /**
   * @brief Accelerometer axes enabling.
   */
  LSM303DLHC_ACC_AE_t    axesenabling;
  /**
   * @brief Accelerometer block data update.
   */
  LSM303DLHC_ACC_BDU_t   blockdataupdate;
  /**
   * @brief Accelerometer block data update.
   */
  LSM303DLHC_ACC_HR_t    highresmode;
  /**
   * @brief Accelerometer endianess.
   */
  LSM303DLHC_ACC_End_t   endianess;
} ACCELConfig;

/**
 * @brief   Structure representing an ACCEL driver.
 */
typedef struct {
  /**
   * @brief Driver state.
   */
  mems_state_t         state;
  /**
   * @brief Current configuration data.
   */
  const ACCELConfig    *config;
  /**
   * @brief Current sensitivity.
   */
  rowdata_t           sensitivity;
} ACCELDriver;
/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

extern ACCELDriver ACCELD1;

#ifdef __cplusplus
extern "C" {
#endif
  void accel_lld_init(void);
  void accel_lld_start(ACCELDriver *accelp);
  void accel_lld_stop(ACCELDriver *accelp);
  void accel_lld_getdata(ACCELDriver *accelp, dataframe_t *data);
  void accel_lld_change_fullscale(ACCELDriver *accelp, ACCELFullScale_t fs);
#ifdef __cplusplus
}
#endif

#endif /* MEMS_USE_ACCEL */

#endif /* _MEMS_ACCEL_LLD_H_ */

/** @} */
