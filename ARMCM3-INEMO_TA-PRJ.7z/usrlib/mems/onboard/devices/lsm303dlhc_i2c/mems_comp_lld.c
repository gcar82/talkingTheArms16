/*
    ChibiOS - Copyright (C) 2016 Rocco Marco Guglielmi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    mems_comp_lld.c
 * @brief   COMP Complex Driver subsystem low level driver source.
 *
 * @addtogroup COMPASS
 * @{
 */

#include "ch.h"
#include "hal.h"

#include "mems.h"

#if MEMS_USE_COMP || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
 * @brief   COMPD1 driver identifier.
 */
COMPDriver COMPD1;

/*===========================================================================*/
/* Driver local types.                                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Low level COMP driver initialization.
 *
 * @notapi
 */
void comp_lld_init(void) {

  compObjectInit(&COMPD1);
}

/**
 * @brief   Configures and activates the COMP Complex Driver peripheral.
 *
 * @param[in] compp      pointer to the @p COMPDriver object
 *
 * @notapi
 */
void comp_lld_start(COMPDriver *compp) {

  chDbgAssert((compp->config->i2cp->state == I2C_READY),
              "comp_lld_start()", "channel not ready");
  lsm303dlhcWriteRegisterI2C(compp->config->i2cp, LSM303DLHC_SAD_COMPASS,
                             LSM303DLHC_SUB_COMP_CRA_REG,
                             compp->config->outputdatarate,
                             NULL);
  lsm303dlhcWriteRegisterI2C(compp->config->i2cp,  LSM303DLHC_SAD_COMPASS,
                             LSM303DLHC_SUB_COMP_CRB_REG,
                             compp->config->fullscale,
                             NULL);
  lsm303dlhcWriteRegisterI2C(compp->config->i2cp,  LSM303DLHC_SAD_COMPASS,
                             LSM303DLHC_SUB_COMP_MR_REG,
                             compp->config->workingmode,
                             NULL);
							 
  /* Storing sensitivity information according to fullscale value */
  if(compp->config->fullscale == LSM303DLHC_COMP_FS_1_3_GA){
    compp->sensitivityXY = LSM303DLHC_COMP_SENS_XY_1_3GA;
    compp->sensitivityZ = LSM303DLHC_COMP_SENS_Z_1_3GA;
  }
  else if(compp->config->fullscale == LSM303DLHC_COMP_FS_1_9_GA){
    compp->sensitivityXY = LSM303DLHC_COMP_SENS_XY_1_9GA;
    compp->sensitivityZ = LSM303DLHC_COMP_SENS_Z_1_9GA;	  
  }
  else if(compp->config->fullscale == LSM303DLHC_COMP_FS_2_5_GA){
    compp->sensitivityXY = LSM303DLHC_COMP_SENS_XY_2_5GA;
    compp->sensitivityZ = LSM303DLHC_COMP_SENS_Z_2_5GA;	  
  }
  else if(compp->config->fullscale == LSM303DLHC_COMP_FS_4_0_GA){
    compp->sensitivityXY = LSM303DLHC_COMP_SENS_XY_4_0GA;
    compp->sensitivityZ = LSM303DLHC_COMP_SENS_Z_4_0GA;	  
  }
  else if(compp->config->fullscale == LSM303DLHC_COMP_FS_4_7_GA){
    compp->sensitivityXY = LSM303DLHC_COMP_SENS_XY_4_7GA;
    compp->sensitivityZ = LSM303DLHC_COMP_SENS_Z_4_7GA;	  
  }
  else if(compp->config->fullscale == LSM303DLHC_COMP_FS_5_6_GA){
    compp->sensitivityXY = LSM303DLHC_COMP_SENS_XY_5_6GA;
    compp->sensitivityZ = LSM303DLHC_COMP_SENS_Z_5_6GA;	  
  }
  else if(compp->config->fullscale == LSM303DLHC_COMP_FS_8_1_GA){
    compp->sensitivityXY = LSM303DLHC_COMP_SENS_XY_8_1GA;
    compp->sensitivityZ = LSM303DLHC_COMP_SENS_Z_8_1GA;	  
  }
  else
    chDbgAssert(FALSE, "comp_lld_start()", "full scale issue");
  /* This is the Comp transient recovery time */
  chThdSleepMilliseconds(5);
}

/**
 * @brief   Deactivates the COMP Complex Driver peripheral.
 *
 * @param[in] compp      pointer to the @p COMPDriver object
 *
 * @notapi
 */
void comp_lld_stop(COMPDriver *compp) {

  if (compp->state == ACTIVE) {
    chDbgAssert((compp->config->i2cp->state == I2C_READY),
                  "comp_lld_stop()", "channel not ready");
    lsm303dlhcWriteRegisterI2C(compp->config->i2cp,  
	                           LSM303DLHC_SAD_COMPASS,
                               LSM303DLHC_SUB_COMP_MR_REG,
                               LSM303DLHC_COMP_WM_SLEEP,
                               NULL);
  }
}

/**
 * @brief   Get data from the COMP Complex Driver peripheral.
 *
 * @param[in] compp      pointer to the @p COMPASS_Driver object
 * @param[in] datap      pointer to the @p comp_dataframe_t object
 *
 * @detail If the output data rate is not chosen by user it is set @ 400 Hz
 * as default value
 * @notapi
 */
void comp_lld_getdata(COMPDriver *compp, dataframe_t *data){

  chDbgAssert((compp->config->i2cp->state == I2C_READY),
                "comp_lld_getdata()", "channel not ready");
  uint8_t low_val, high_val;
  int16_t value;
  rowdata_t* datap = (rowdata_t*)data;

  low_val = lsm303dlhcReadRegisterI2C(compp->config->i2cp,
                                      LSM303DLHC_SAD_COMPASS,
                                      LSM303DLHC_SUB_COMP_OUT_X_L, NULL);
  high_val =lsm303dlhcReadRegisterI2C(compp->config->i2cp,
                                      LSM303DLHC_SAD_COMPASS,
                                      LSM303DLHC_SUB_COMP_OUT_X_H, NULL);
  value = (high_val << 8) + low_val;
  *datap = value / compp->sensitivityXY;
  datap++;

  low_val = lsm303dlhcReadRegisterI2C(compp->config->i2cp,
                                      LSM303DLHC_SAD_COMPASS,
                                      LSM303DLHC_SUB_COMP_OUT_Y_L, NULL);
  high_val =lsm303dlhcReadRegisterI2C(compp->config->i2cp,
                                      LSM303DLHC_SAD_COMPASS,
                                      LSM303DLHC_SUB_COMP_OUT_Y_H, NULL);
  value = (high_val << 8) + low_val;
  *datap = value / compp->sensitivityXY;
  datap++;
  
  low_val = lsm303dlhcReadRegisterI2C(compp->config->i2cp,
                                      LSM303DLHC_SAD_COMPASS,
                                      LSM303DLHC_SUB_COMP_OUT_Z_L, NULL);
  high_val =lsm303dlhcReadRegisterI2C(compp->config->i2cp,
                                      LSM303DLHC_SAD_COMPASS,
                                      LSM303DLHC_SUB_COMP_OUT_Z_H, NULL);
  value = (high_val << 8) + low_val;
  *datap = value / compp->sensitivityZ;
}

/**
 * @brief   Changes the full scale value of the COMP Complex Driver peripheral.
 * @note    I2C must be started
 *
 * @param[in] compp      pointer to the @p COMPDriver object
 * @param[in] fs         the chosen full scale value
 *
 * @notapi
 */
void comp_lld_change_fullscale(COMPDriver *compp, COMPFullScale_t fs){
  uint8_t value;
  chDbgAssert((compp->config->i2cp->state == I2C_READY),
              "comp_lld_change_fullscale()", "channel not ready");
  value = lsm303dlhcReadRegisterI2C(compp->config->i2cp,
                                    LSM303DLHC_SAD_COMPASS,
                                    LSM303DLHC_SUB_COMP_CRB_REG,
                                    NULL);
  lsm303dlhcWriteRegisterI2C(compp->config->i2cp,
                             LSM303DLHC_SAD_COMPASS,
                             LSM303DLHC_SUB_COMP_CRB_REG,
                             ((fs & LSM303DLHC_SUB_COMP_CRB_REG_FS) |
                             (value & (~LSM303DLHC_SUB_COMP_CRB_REG_FS))),
                             NULL);
  /* Storing sensitivity information according to fullscale value */
  if(fs == LSM303DLHC_COMP_FS_1_3_GA){
    compp->sensitivityXY = LSM303DLHC_COMP_SENS_XY_1_3GA;
    compp->sensitivityZ = LSM303DLHC_COMP_SENS_Z_1_3GA;
  }
  else if(fs == LSM303DLHC_COMP_FS_1_9_GA){
    compp->sensitivityXY = LSM303DLHC_COMP_SENS_XY_1_9GA;
    compp->sensitivityZ = LSM303DLHC_COMP_SENS_Z_1_9GA;
  }
  else if(fs == LSM303DLHC_COMP_FS_2_5_GA){
    compp->sensitivityXY = LSM303DLHC_COMP_SENS_XY_2_5GA;
    compp->sensitivityZ = LSM303DLHC_COMP_SENS_Z_2_5GA;
  }
  else if(fs == LSM303DLHC_COMP_FS_4_0_GA){
    compp->sensitivityXY = LSM303DLHC_COMP_SENS_XY_4_0GA;
    compp->sensitivityZ = LSM303DLHC_COMP_SENS_Z_4_0GA;
  }
  else if(fs == LSM303DLHC_COMP_FS_4_7_GA){
    compp->sensitivityXY = LSM303DLHC_COMP_SENS_XY_4_7GA;
    compp->sensitivityZ = LSM303DLHC_COMP_SENS_Z_4_7GA;
  }
  else if(fs == LSM303DLHC_COMP_FS_5_6_GA){
    compp->sensitivityXY = LSM303DLHC_COMP_SENS_XY_5_6GA;
    compp->sensitivityZ = LSM303DLHC_COMP_SENS_Z_5_6GA;
  }
  else if(fs == LSM303DLHC_COMP_FS_8_1_GA){
    compp->sensitivityXY = LSM303DLHC_COMP_SENS_XY_8_1GA;
    compp->sensitivityZ = LSM303DLHC_COMP_SENS_Z_8_1GA;
  }
  else
    chDbgAssert(FALSE, "comp_lld_change_fullscale()", "full scale issue");
}
#endif /* MEMS_USE_COMP */

/** @} */
