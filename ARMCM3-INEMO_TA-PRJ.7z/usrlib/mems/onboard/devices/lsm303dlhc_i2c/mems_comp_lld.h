/*
    ChibiOS - Copyright (C) 2016 Rocco Marco Guglielmi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    mems_comp_lld.h
 * @brief   COMP Complex Driver subsystem low level driver header.
 *
 * @addtogroup COMP
 * @{
 */

#ifndef _COMP_LLD_H_
#define _COMP_LLD_H_

#include "mems.h"

#if MEMS_USE_COMP || defined(__DOXYGEN__)

#include "lsm303dlhc.h"
/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/**
 * @brief   Number of axes.
 */
#define COMP_AXES                                0x03
/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

#if !HAL_USE_I2C
#error "LSM303DLHC Over I2C requires HAL_USE_I2C."
#endif
/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

#include "unified_mems_dt.h"

/**
 * @brief   COMP full scale type
 */
typedef  LSM303DLHC_COMP_FS_t COMPFullScale_t;

/**
 * @brief   COMP configuration structure.
 */
typedef struct {

  /**
   * @brief I2C driver associated to this GYROSCOPE.
   */
  I2CDriver  *i2cp;
  /**
   * @brief Compass fullscale value.
   */
  LSM303DLHC_COMP_FS_t    fullscale;
  /**
   * @brief Compass output data rate selection.
   */
  LSM303DLHC_COMP_ODR_t   outputdatarate;
  /**
   * @brief Compass working mode.
   */
  LSM303DLHC_COMP_WM_t    workingmode;
} COMPConfig;

/**
 * @brief   Structure representing a COMP driver.
 */
typedef struct {
  /**
   * @brief Driver state.
   */
  mems_state_t         state;
  /**
   * @brief Current configuration data.
   */
  const COMPConfig     *config;
  /**
   * @brief Current sensitivity on X and Y axis.
   */
  rowdata_t           sensitivityXY;
  /**
   * @brief Current sensitivity on Z.
   */
  rowdata_t           sensitivityZ;
} COMPDriver;
/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

extern COMPDriver COMPD1;

#ifdef __cplusplus
extern "C" {
#endif
  void comp_lld_init(void);
  void comp_lld_start(COMPDriver *compp);
  void comp_lld_stop(COMPDriver *compp);
  void comp_lld_getdata(COMPDriver *compp, dataframe_t *data);
  void comp_lld_change_fullscale(COMPDriver *compp, COMPFullScale_t fs);
#ifdef __cplusplus
}
#endif

#endif /* MEMS_USE_COMP */

#endif /* _COMP_LLD_H_ */

/** @} */
