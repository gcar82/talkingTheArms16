/*
    ChibiOS - Copyright (C) 2016 Rocco Marco Guglielmi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    accel_lld.c
 * @brief   ACCEL Complex Driver subsystem low level driver source.
 *
 * @addtogroup ACCEL
 * @{
 */

#include "ch.h"
#include "hal.h"

#include "mems.h"

#if MEMS_USE_ACCEL || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
 * @brief   ACCELD1 driver identifier.
 */
ACCELDriver ACCELD1;
/*===========================================================================*/
/* Driver local types.                                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Low level ACCEL driver initialization.
 *
 * @notapi
 */
void accel_lld_init(void) {

  accelObjectInit(&ACCELD1);
}

/**
 * @brief   Configures and activates the ACCEL Complex Driver peripheral.
 * @note    I2C must be started
 *
 * @param[in] accelp      pointer to the @p ACCEL_Driver object
 *
 * @notapi
 */
void accel_lld_start(ACCELDriver *accelp) {

  chDbgAssert((accelp->config->i2cp->state == I2C_READY),
              "accel_lld_start()", "channel not ready");
  lsm303dlhcWriteRegisterI2C(accelp->config->i2cp, LSM303DLHC_SAD_ACCEL,
                             LSM303DLHC_SUB_ACC_CTRL_REG1,
                             accelp->config->outputdatarate |
                             LSM303DLHC_ACC_PM_NORMAL |
                             accelp->config->axesenabling,
                             NULL);
  lsm303dlhcWriteRegisterI2C(accelp->config->i2cp,  LSM303DLHC_SAD_ACCEL,
                             LSM303DLHC_SUB_ACC_CTRL_REG4,
                             accelp->config->blockdataupdate |
                             accelp->config->endianess |
                             accelp->config->fullscale |
                             accelp->config->highresmode,
                             NULL);
					   
  /* Storing sensitivity information according to fullscale value */
  if(accelp->config->fullscale == LSM303DLHC_ACC_FS_2G)
    accelp->sensitivity = LSM303DLHC_ACC_SENS_2G;
  else if(accelp->config->fullscale == LSM303DLHC_ACC_FS_4G)
    accelp->sensitivity = LSM303DLHC_ACC_SENS_4G;
  else if(accelp->config->fullscale == LSM303DLHC_ACC_FS_8G)
    accelp->sensitivity = LSM303DLHC_ACC_SENS_8G;
  else if(accelp->config->fullscale == LSM303DLHC_ACC_FS_16G)
    accelp->sensitivity = LSM303DLHC_ACC_SENS_16G;
  else
    chDbgAssert(FALSE, "accel_lld_start()", "full scale issue");
  /* This is the Accelerometer transient recovery time */
  chThdSleepMilliseconds(5);
}

/**
 * @brief   Deactivates the ACCEL Complex Driver  peripheral.
 * @note    I2C must be started
 *
 * @param[in] accelp      pointer to the @p ACCEL_Driver object
 *
 * @notapi
 */
void accel_lld_stop(ACCELDriver *accelp) {
	
  chDbgAssert((accelp->config->i2cp->state == I2C_READY),
                "accel_lld_stop()", "channel not ready");
  if (accelp->state == ACTIVE) {
    lsm303dlhcWriteRegisterI2C(accelp->config->i2cp,  
	                           LSM303DLHC_SAD_ACCEL,
                               LSM303DLHC_SUB_ACC_CTRL_REG1,
                               LSM303DLHC_ACC_PM_LOW_POWER, NULL);
  }
}

/**
 * @brief   Get data from the ACCEL Complex Driver peripheral.
 * @note    I2C must be started
 *
 * @param[in] accelp      pointer to the @p ACCEL_Driver object
 * @param[in] data        pointer to the @p accel_dataframe_t object
 *
 * @detail If the output data rate is not chosen by user it is set @ 400 Hz
 * as default value
 * @notapi
 */
void accel_lld_getdata(ACCELDriver *accelp, dataframe_t *data) {

  chDbgAssert((accelp->config->i2cp->state == I2C_READY),
              "accel_lld_getdata()", "channel not ready");
  uint8_t low_val, high_val;
  int16_t value;
  rowdata_t* datap = (rowdata_t*)data;

  if(accelp->config->axesenabling & LSM303DLHC_ACC_AE_X){
    low_val = lsm303dlhcReadRegisterI2C(accelp->config->i2cp,
                                        LSM303DLHC_SAD_ACCEL,
                                        LSM303DLHC_SUB_ACC_OUT_X_L, NULL);
    high_val =lsm303dlhcReadRegisterI2C(accelp->config->i2cp,
                                        LSM303DLHC_SAD_ACCEL,
                                        LSM303DLHC_SUB_ACC_OUT_X_H, NULL);
    value = (high_val << 8) + low_val;
    *datap = value * accelp->sensitivity;
    datap++;
  }
  if(accelp->config->axesenabling & LSM303DLHC_ACC_AE_Y){
    low_val = lsm303dlhcReadRegisterI2C(accelp->config->i2cp,
                                        LSM303DLHC_SAD_ACCEL,
                                        LSM303DLHC_SUB_ACC_OUT_Y_L, NULL);
    high_val =lsm303dlhcReadRegisterI2C(accelp->config->i2cp,
                                        LSM303DLHC_SAD_ACCEL,
                                        LSM303DLHC_SUB_ACC_OUT_Y_H, NULL);
    value = (high_val << 8) + low_val;
    *datap = (value >> 4)  * accelp->sensitivity;
    datap++;
  }
  if(accelp->config->axesenabling & LSM303DLHC_ACC_AE_Z){
    low_val = lsm303dlhcReadRegisterI2C(accelp->config->i2cp,
                                        LSM303DLHC_SAD_ACCEL,
                                        LSM303DLHC_SUB_ACC_OUT_Z_L, NULL);
    high_val =lsm303dlhcReadRegisterI2C(accelp->config->i2cp,
                                        LSM303DLHC_SAD_ACCEL,
                                        LSM303DLHC_SUB_ACC_OUT_Z_H, NULL);
    value = (high_val << 8) + low_val;
    *datap = (value >> 4) * accelp->sensitivity;
  }
}

/**
 * @brief   Changes the full scale value of the ACCEL Complex Driver peripheral.
 * @note    I2C must be started
 *
 * @param[in] accelp      pointer to the @p ACCELDriver object
 * @param[in] fs         the chosen full scale value
 *
 * @notapi
 */
void accel_lld_change_fullscale(ACCELDriver *accelp, ACCELFullScale_t fs){
  uint8_t value;
  chDbgAssert((accelp->config->i2cp->state == I2C_READY),
              "accel_lld_change_fullscale()", "channel not ready");
  value = lsm303dlhcReadRegisterI2C(accelp->config->i2cp,
                                    LSM303DLHC_SAD_ACCEL,
                                    LSM303DLHC_SUB_ACC_CTRL_REG4, 
									NULL);
  lsm303dlhcWriteRegisterI2C(accelp->config->i2cp,
                          LSM303DLHC_SAD_ACCEL,
                          LSM303DLHC_SUB_ACC_CTRL_REG4,
                          ((fs & LSM303DLHC_SUB_ACC_CTRL_REG4_FS) |
                          (value & (~LSM303DLHC_SUB_ACC_CTRL_REG4_FS))), 
						  NULL);
  /* Storing sensitivity information according to fullscale value */
  if(fs == LSM303DLHC_ACC_FS_2G)
    accelp->sensitivity = LSM303DLHC_ACC_SENS_2G;
  else if(fs == LSM303DLHC_ACC_FS_4G)
    accelp->sensitivity = LSM303DLHC_ACC_SENS_4G;
  else if(fs == LSM303DLHC_ACC_FS_8G)
    accelp->sensitivity = LSM303DLHC_ACC_SENS_8G;
  else if(fs == LSM303DLHC_ACC_FS_16G)
    accelp->sensitivity = LSM303DLHC_ACC_SENS_16G;
  else
    chDbgAssert(FALSE, "accel_lld_change_fullscale()", "full scale issue");
}
#endif /* MEMS_USE_ACCEL */

/** @} */
