/*
    ChibiOS - Copyright (C) 2016 Rocco Marco Guglielmi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    mems_gyro_lld.c
 * @brief   GYRO Complex Driver subsystem low level driver source.
 *
 * @addtogroup GYRO
 * @{
 */

#include "ch.h"
#include "hal.h"

#include "mems.h"

#if MEMS_USE_GYRO || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/**
 * @brief   GYROD1 driver identifier.
 */
GYRODriver GYROD1;
/*===========================================================================*/
/* Driver local types.                                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/

/*===========================================================================*/
/* Driver interrupt handlers.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

/**
 * @brief   Low level GYRO driver initialization.
 *
 * @notapi
 */
void gyro_lld_init(void) {

  gyroObjectInit(&GYROD1);
}

/**
 * @brief   Configures and activates the GYRO Complex Driver peripheral.
 * @note    SPI must be started
 *
 * @param[in] gyrop      pointer to the @p GYRODriver object
 *
 * @notapi
 */
void gyro_lld_start(GYRODriver *gyrop) {

  chDbgAssert((gyrop->config->spip->state == SPI_READY),
              "gyro_lld_start()", "channel not ready");
#if  SPI_USE_MUTUAL_EXCLUSION
  spiAcquireBus(gyrop->config->spip);
#endif
  l3gd20WriteRegisterSPI(gyrop->config->spip, L3GD20_AD_CTRL_REG1,
                         gyrop->config->axesenabling |
                         L3GD20_PM_SLEEP_NORMAL |
                         gyrop->config->outputdatarate);
  l3gd20WriteRegisterSPI(gyrop->config->spip, L3GD20_AD_CTRL_REG4,
                         gyrop->config->fullscale |
                         gyrop->config->blockdataupdate |
                         gyrop->config->endianess);
#if  SPI_USE_MUTUAL_EXCLUSION
  spiReleaseBus(gyrop->config->spip);
#endif
  /* Storing sensitivity information according to fullscale value */
  if(gyrop->config->fullscale == L3GD20_FS_250DPS)
    gyrop->sensitivity = L3GD20_SENS_250DPS;
  else if(gyrop->config->fullscale == L3GD20_FS_500DPS)
    gyrop->sensitivity = L3GD20_SENS_500DPS;
  else if(gyrop->config->fullscale == L3GD20_FS_2000DPS)
    gyrop->sensitivity = L3GD20_SENS_2000DPS;
  else
    chDbgAssert(FALSE, "gyro_lld_start()", "full scale issue");
  /* This is the Gyroscope transient recovery time */
  chThdSleepMilliseconds(10);
}

/**
 * @brief   Deactivates the GYRO Complex Driver peripheral.
 * @note    SPI must be started
 *
 * @param[in] gyrop      pointer to the @p GYRODriver object
 *
 * @notapi
 */
void gyro_lld_stop(GYRODriver *gyrop) {

  chDbgAssert((gyrop->config->spip->state == SPI_READY),
              "gyro_lld_stop()", "channel not ready");
  if (gyrop->state == ACTIVE) {
#if  SPI_USE_MUTUAL_EXCLUSION
  spiAcquireBus(gyrop->config->spip);
#endif
    l3gd20WriteRegisterSPI(gyrop->config->spip, L3GD20_AD_CTRL_REG1,
                        L3GD20_PM_POWER_DOWN | L3GD20_AE_DISABLED);
#if  SPI_USE_MUTUAL_EXCLUSION
  spiReleaseBus(gyrop->config->spip);
#endif
  }

}

/**
 * @brief   Get data from the GYRO Complex Driver peripheral.
 * @note    SPI must be started
 *
 * @param[in] gyrop      pointer to the @p GYRODriver object
 * @param[in] data       pointer to the @p GYRODataframe_t object
 
 * @notapi
 */
void gyro_lld_getdata(GYRODriver *gyrop, dataframe_t *data) {

  chDbgAssert((gyrop->config->spip->state == SPI_READY),
              "gyro_lld_getdata()", "channel not ready");
  uint8_t low_val, high_val;
  int16_t value;
  rowdata_t* offp = (rowdata_t*)&gyrop->offset;
  rowdata_t* datap = (rowdata_t*)data;

#if  SPI_USE_MUTUAL_EXCLUSION
  spiAcquireBus(gyrop->config->spip);
#endif
  if(gyrop->config->axesenabling & L3GD20_AE_X){
    low_val = l3gd20ReadRegisterSPI(gyrop->config->spip, L3GD20_AD_OUT_X_L);
    high_val = l3gd20ReadRegisterSPI(gyrop->config->spip, L3GD20_AD_OUT_X_H);
    value = (high_val << 8) + low_val;
    *datap = value * gyrop->sensitivity;
    *datap -= *offp;
    datap++;
    offp++;
  }
  if(gyrop->config->axesenabling & L3GD20_AE_Y){
    low_val = l3gd20ReadRegisterSPI(gyrop->config->spip, L3GD20_AD_OUT_Y_L);
    high_val = l3gd20ReadRegisterSPI(gyrop->config->spip, L3GD20_AD_OUT_Y_H);
    value = (high_val << 8) + low_val;
    *datap = value * gyrop->sensitivity;
    *datap -= *offp;
    datap++;
    offp++;
  }
  if(gyrop->config->axesenabling & L3GD20_AE_Z){
    low_val = l3gd20ReadRegisterSPI(gyrop->config->spip, L3GD20_AD_OUT_Z_L);
    high_val = l3gd20ReadRegisterSPI(gyrop->config->spip, L3GD20_AD_OUT_Z_H);
    value = (high_val << 8) + low_val;
    *datap = value * gyrop->sensitivity;
    *datap -= *offp;
  }
#if  SPI_USE_MUTUAL_EXCLUSION
  spiReleaseBus(gyrop->config->spip);
#endif
}

/**
 * @brief   Changes the full scale value of the GYRO Complex Driver peripheral.
 * @note    SPI must be started
 *
 * @param[in] gyrop      pointer to the @p GYRODriver object
 * @param[in] fs         the chosen full scale value
 *
 * @notapi
 */
void gyro_lld_change_fullscale(GYRODriver *gyrop, GYROFullScale_t fs){
  uint8_t value;
  chDbgAssert((gyrop->config->spip->state == SPI_READY),
              "gyro_lld_change_fullscale()", "channel not ready");
#if  SPI_USE_MUTUAL_EXCLUSION
  spiAcquireBus(gyrop->config->spip);
#endif
  value = l3gd20ReadRegisterSPI(gyrop->config->spip, L3GD20_AD_CTRL_REG4);
  l3gd20WriteRegisterSPI(gyrop->config->spip, L3GD20_AD_CTRL_REG4,
                         ((fs & L3GD20_CTRL_REG4_FS) |
                         (value & (~L3GD20_CTRL_REG4_FS))));
#if  SPI_USE_MUTUAL_EXCLUSION
  spiReleaseBus(gyrop->config->spip);
#endif
  /* Storing sensitivity information according to fullscale value */
  if(fs == L3GD20_FS_250DPS)
    gyrop->sensitivity = L3GD20_SENS_250DPS;
  else if(fs == L3GD20_FS_500DPS)
    gyrop->sensitivity = L3GD20_SENS_500DPS;
  else if(fs == L3GD20_SENS_2000DPS)
    gyrop->sensitivity = L3GD20_SENS_2000DPS;
  else
    chDbgAssert(FALSE, "gyro_lld_change_fullscale()", "full scale issue");
}
#endif /* MEMS_USE_GYRO */

/** @} */
