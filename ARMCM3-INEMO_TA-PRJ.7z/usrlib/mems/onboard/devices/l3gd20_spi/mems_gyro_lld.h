/*
    ChibiOS - Copyright (C) 2016 Rocco Marco Guglielmi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    mems_gyro_lld.h
 * @brief   GYRO Complex Driver subsystem low level driver header.
 *
 * @addtogroup GYRO
 * @{
 */

#ifndef _MEMS_GYRO_LLD_H_
#define _MEMS_GYRO_LLD_H_

#include "mems.h"

#if MEMS_USE_GYRO || defined(__DOXYGEN__)

#include "l3gd20.h"
/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/**
 * @brief   Number of axes.
 */
#define GYRO_AXES                                0x03
/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

#if !HAL_USE_SPI
#error "L3GD20 Over SPI requires HAL_USE_SPI."
#endif
/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

#include "unified_mems_dt.h"

/**
 * @brief   GYRO full scale type
 */
typedef  L3GD20_FS_t         GYROFullScale_t;

/**
 * @brief   GYRO configuration structure.
 */
typedef struct {

  /**
   * @brief SPI driver associated to this GYROSCOPE.
   */
  SPIDriver      *spip;
  /**
   * @brief Gyroscope fullscale value.
   */
  L3GD20_FS_t    fullscale;
  /**
   * @brief Gyroscope output data rate selection.
   */
  L3GD20_ODR_t   outputdatarate;
  /**
   * @brief Gyroscope axes enabling.
   */
  L3GD20_AE_t    axesenabling;
  /**
   * @brief Gyroscope endianess.
   */
  L3GD20_End_t   endianess;
  /**
   * @brief Gyroscope block data update.
   */
  L3GD20_BDU_t   blockdataupdate;
} GYROConfig;

/**
 * @brief   Structure representing a GYRO driver.
 */
typedef struct {
  /**
   * @brief Driver state.
   */
  mems_state_t         state;
  /**
   * @brief Current configuration data.
   */
  const GYROConfig     *config;
  /**
   * @brief Offset structure.
   */
  dataframe_t          offset;
  /**
   * @brief Current sensitivity.
   */
  rowdata_t            sensitivity;
} GYRODriver;
/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

extern GYRODriver GYROD1;

#ifdef __cplusplus
extern "C" {
#endif
  void gyro_lld_init(void);
  void gyro_lld_start(GYRODriver *gyrop);
  void gyro_lld_stop(GYRODriver *gyrop);
  void gyro_lld_getdata(GYRODriver *gyrop, dataframe_t *data);
  void gyro_lld_change_fullscale(GYRODriver *gyrop, GYROFullScale_t fs);
#ifdef __cplusplus
}
#endif

#endif /* MEMS_USE_GYRO */

#endif /* _MEMS_GYRO_LLD_H_ */

/** @} */
