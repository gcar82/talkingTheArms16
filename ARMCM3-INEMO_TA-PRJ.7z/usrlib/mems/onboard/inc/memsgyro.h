/*
    ChibiOS - Copyright (C) 2016 Rocco Marco Guglielmi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    memsgyro.h
 * @brief   GYRO complex driver header.
 *
 * @addtogroup GYRO
 * @{
 */

#ifndef _MEMSGYRO_H_
#define _MEMSGYRO_H_

#if MEMS_USE_GYRO || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/**
 * @brief   Number of acquisitions for offset
 * @details This is the number of acquisitions performed to compute the
 *          offset. A repetition is required in order to remove noise.
 */
#if !defined(GYRO_OFF_ACQ_TIMES)
#define GYRO_OFF_ACQ_TIMES                             50
#endif

/**
 * @brief   Settling time for offset
 * @details This is the time waited between each offset acquisition.
 * @note
 */
#if !defined(GYRO_OFF_SET_TIME_uS)
#define GYRO_OFF_SET_TIME_uS                           5000
#endif
/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

#include "mems_gyro_lld.h"


/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#ifdef __cplusplus
extern "C" {
#endif
  void gyroInit(void);
  void gyroObjectInit(GYRODriver *gyrop);
  void gyroStart(GYRODriver *gyrop, const GYROConfig *config);
  void gyroStop(GYRODriver *gyrop);
  void gyroGetOffset(GYRODriver *gyrop);
  void gyroResetOffset(GYRODriver *gyrop);
  void gyroGetData(GYRODriver *gyrop, dataframe_t *datap);
  void gyroChangeFullScale(GYRODriver *gyrop, GYROFullScale_t fs);
#ifdef __cplusplus
}
#endif
#endif /* MEMS_USE_GYRO */
#endif /* _MEMSGYRO_H_ */

/** @} */
