/*
    ChibiOS - Copyright (C) 2016 Rocco Marco Guglielmi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    mems.h
 * @brief   MEMS header.
 *
 * @addtogroup MEMS
 * @{
 */

#ifndef _MEMS_H_
#define _MEMS_H_
/**
 * @brief   MEMS identification macro.
 */
#define _MEMS_

/**
 * @brief   MEMS version string.
 */
#define MEMS_VERSION       "0.2.0"

/**
 * @name    MEMS version
 * @{
 */
/**
 * @brief   MEMS version major number.
 */
#define MEMS_MAJOR         0

/**
 * @brief   MEMS version minor number.
 */
#define MEMS_MINOR         2

/**
 * @brief   MEMS version patch number.
 */
#define MEMS_PATCH         0
/** @} */

#include "memsconf.h"

/* Abstract interfaces.*/


/* Shared headers.*/


/* Layered drivers.*/


/* Complex drivers.*/
#include "memsgyro.h"
#include "memsaccel.h"
#include "memscomp.h"
/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#ifdef __cplusplus
extern "C" {
#endif
  void memsInit(void);
#ifdef __cplusplus
}
#endif

#endif /* _MEMS_H_ */

/** @} */
