/*
    ChibiOS - Copyright (C) 2016 Gennaro Carola

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/**
 * @file    gloves.h
 * @brief   Glove data device Complex Driver header.
 *
 * @addtogroup GLOVE_DEVICE
 * @{
 */

#ifndef GLOVES_H_
#define GLOVES_H_

#include "mems.h"
#include "p_mems.h"

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/**
 * @brief Alias names
 *        for i2c and spi chibios drives
 */
#define ON_BOARD_I2C_DRV I2CD2
#define ON_BOARD_SPI_DRV SPID2
#define PERIPH_I2C_DRV   I2CD1

/**
 * @brief  Size Buffer Array
 */
#define GLOVE_DATA_SIZE 21

/**
 * @brief  Logic Addresses Data
 */
#define INDEX_DIP_ACC    0
#define INDEX_DIP_GYRO   1
#define INDEX_PIP_ACC    2
#define INDEX_PIP_GYRO   3
#define MIDDLE_DIP_ACC   4
#define MIDDLE_DIP_GYRO  5
#define MIDDLE_PIP_ACC   6
#define MIDDLE_PIP_GYRO  7
#define RING_DIP_ACC     8
#define RING_DIP_GYRO    9
#define RING_PIP_ACC    10
#define RING_PIP_GYRO   11
#define PINKY_DIP_ACC   12
#define PINKY_DIP_GYRO  13
#define PINKY_PIP_ACC   14
#define PINKY_PIP_GYRO  15
#define THUMB_DIP_ACC   16
#define THUMB_DIP_GYRO  17
#define WRIST_ACC       18
#define WRIST_GYRO      19
#define WRIST_MAG       20
/*===========================================================================*/
/* Driver pre-compile time settings.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/**
 * @brief   phalanx structure.
 */
typedef struct {
  /**
   *  @brief   Pointer to the @p the MPU6050 MEMS Complex Driver peripheral.
   */
  MPU6050Driver *devp;
  /**
   *  @brief   Pointer to the @p the configuration for
   *           MPU6050 MEMS Complex Driver peripheral.
   */
  MPU6050Config *config;

}phalanx_t;

/**
 * @brief   finger structure.
 */
typedef struct {
  /**
   * @brief   Pointer to the @p phalanx_t object.
   * @note    MEMS sensors of dip phalanx for the fingers.
   */
  phalanx_t *dip;
  /**
   * @brief   Pointer to the @p phalanx_t object.
   * @note    MEMS sensors of pip phalanx for the fingers.
   */
  phalanx_t *pip;

} finger_t;

/**
 * @brief   wrist structure.
 */
typedef struct {
  /**
   *  @brief   Pointer to the @p the ACCEL Complex Driver peripheral.
   */
  ACCELDriver *accelp;
  /**
   *  @brief   Pointer to the @p the GYRO Complex Driver peripheral.
   */
  GYRODriver  *gyrop;
  /**
   *  @brief   Pointer to the @p the COMP Complex Driver peripheral.
   */
  COMPDriver  *compp;
  /**
   *  @brief   Pointer to the @p the configuration for
   *           ACCEL Complex Driver peripheral.
   */
  ACCELConfig *accelcfg;
  /**
   *  @brief   Pointer to the @p the configuration for
   *           GYRO Complex Driver peripheral.
   */
  GYROConfig  *gyrocfg;
  /**
   *  @brief   Pointer to the @p the configuration for
   *           COMP Complex Driver peripheral.
   */
  COMPConfig  *compcfg;
}mcuWrist_t;

/**
 * @brief   side hand type.
 */
typedef enum {
  RIGHT = 0,  /**< right side hand.*/
  LEFT  = 1,  /**< left side hand. */
} handSide_t;

/**
 * @brief   Driver state machine possible states.
 */
typedef enum {
  UNINITIALIZED    =   0,  /**< Not initialized.*/
  UNACTIVE         =   1,  /**< Stopped.        */
  READY            =   2,  /**< Sampling data.  */
} gloveState_t;

/**
 * @brief   hand structure.
 */
typedef struct {
  /**
   * @brief   Side hand.
   */
  handSide_t   side;
  /**
   * @brief   Current Driver state.
   */
  gloveState_t state;
  /**
   * @brief   Pointer to the @p wrist_t object.
   */
  mcuWrist_t   *wrist;
  /**
   * @brief   Pointer to the @p finger_t object stands for thumb finger.
   */
  finger_t     *thumb;
  /**
   * @brief   Pointer to the @p finger_t object stands for index finger.
   */
  finger_t     *index;
  /**
   * @brief   Pointer to the @p finger_t object stands for middle finger.
   */
  finger_t     *middle;
  /**
   * @brief   Pointer to the @p finger_t object stands for ring finger.
   */
  finger_t     *ring;
  /**
   * @brief   Pointer to the @p finger_t object stands for pinky finger.
   */
  finger_t     *pinky;
} gloves_t;
/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

extern gloves_t glv_dx;

#ifdef __cplusplus
extern "C" {
#endif
void initGloves(void);
gloveState_t stopDataGloves(gloves_t *glv_dx);
gloveState_t getDataGloves(gloves_t *glv_dx, dataframe_t *glv_df);
gloveState_t startDataGloves(gloves_t *glv_dx);
#ifdef __cplusplus
}
#endif

#endif /* GLOVES_H_ */
